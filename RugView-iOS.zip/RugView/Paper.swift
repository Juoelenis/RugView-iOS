import Foundation

/// Local paper trading on a constant-product pool (x*y=k, no fees). An estimate, not Rugplay's exact math.
final class Paper: ObservableObject {
    @Published var cash: Double { didSet { UserDefaults.standard.set(cash, forKey: "pcash") } }
    @Published var hold: [String: Double] { didSet { UserDefaults.standard.set(hold, forKey: "phold") } }
    init() {
        let d = UserDefaults.standard
        cash = d.object(forKey: "pcash") as? Double ?? 1000
        hold = d.dictionary(forKey: "phold") as? [String: Double] ?? [:]
    }
    func reset() { cash = 1000; hold = [:] }
    func buy(_ s: String, _ spend: Double, _ c: Double, _ b: Double) -> String {
        guard c > 0, b > 0 else { return "No pool data" }
        guard spend > 0 else { return "Enter an amount" }
        guard spend <= cash else { return "Not enough paper cash" }
        let out = c - c * b / (b + spend)
        cash -= spend; hold[s, default: 0] += out
        return "Bought \(fmt(out)) \(s)"
    }
    func sell(_ s: String, _ amt: Double, _ c: Double, _ b: Double) -> String {
        guard c > 0, b > 0 else { return "No pool data" }
        guard amt > 0 else { return "Enter an amount" }
        guard amt <= (hold[s] ?? 0) else { return "You don't hold that many" }
        let out = b - c * b / (c + amt)
        cash += out; hold[s, default: 0] -= amt
        return "Sold for $\(fmt(out))"
    }
}
