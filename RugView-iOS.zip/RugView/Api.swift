import Foundation

enum ApiError: LocalizedError {
    case msg(String)
    var errorDescription: String? { if case .msg(let m) = self { return m }; return nil }
}

enum Api {
    static func get<T: Decodable>(_ path: String, key: String) async throws -> T {
        guard let url = URL(string: "https://rugplay.com/api/v1" + path) else { throw ApiError.msg("Bad URL") }
        var req = URLRequest(url: url)
        req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        let (data, resp) = try await URLSession.shared.data(for: req)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        guard code == 200 else {
            let m: [Int: String] = [400: "Bad request", 401: "Invalid or missing API key", 404: "Not found", 429: "Rate limit hit (2,000/day)"]
            throw ApiError.msg(m[code] ?? "HTTP \(code)")
        }
        return try JSONDecoder().decode(T.self, from: data)
    }
}

struct MarketResp: Decodable { let coins: [MCoin] }
struct MCoin: Decodable, Identifiable {
    let symbol: String; let name: String?
    let currentPrice: Double?; let marketCap: Double?; let change24h: Double?
    var id: String { symbol }
}
struct CoinResp: Decodable { let coin: CoinInfo; let candlestickData: [Candle]? }
struct CoinInfo: Decodable {
    let symbol: String; let name: String?
    let currentPrice: Double?; let marketCap: Double?; let volume24h: Double?; let change24h: Double?
    let poolCoinAmount: Double?; let poolBaseCurrencyAmount: Double?
    let creatorName: String?; let creatorUsername: String?
}
struct Candle: Decodable { let time: Double; let open: Double; let high: Double; let low: Double; let close: Double }
struct HoldersResp: Decodable { let holders: [Holder] }
struct Holder: Decodable, Identifiable { let rank: Int; let username: String?; let percentage: Double?; var id: Int { rank } }
struct HopResp: Decodable { let questions: [Question] }
struct Question: Decodable, Identifiable {
    let id: Int; let question: String
    let yesPercentage: Double?; let noPercentage: Double?; let totalAmount: Double?
}

func fmt(_ d: Double) -> String {
    let a = abs(d)
    if a >= 1e12 { return String(format: "%.2fT", d / 1e12) }
    if a >= 1e9 { return String(format: "%.2fB", d / 1e9) }
    if a >= 1e6 { return String(format: "%.2fM", d / 1e6) }
    if a >= 1e3 { return String(format: "%.2fK", d / 1e3) }
    if a >= 1 { return String(format: "%.2f", d) }
    return String(format: "%.6f", d)
}
func smaOf(_ v: [Double], _ n: Int) -> [Double?] {
    v.indices.map { i -> Double? in i + 1 < n ? nil : v[(i + 1 - n)...i].reduce(0, +) / Double(n) }
}
func emaOf(_ v: [Double], _ n: Int) -> [Double?] {
    let k = 2.0 / Double(n + 1); var e: Double? = nil
    return v.map { x -> Double? in
        let nv: Double = e == nil ? x : x * k + e! * (1 - k); e = nv; return nv
    }
}
