import SwiftUI
import Charts
import WebKit

private func isCancel(_ e: Error) -> Bool {
    e is CancellationError || (e as? URLError)?.code == .cancelled
}

struct MarketView: View {
    @AppStorage("apikey") private var key = ""
    @State private var coins: [MCoin] = []
    @State private var q = ""
    @State private var sort = "marketCap"
    @State private var err: String?

    var body: some View {
        NavigationStack {
            List {
                if let err { Text(err).foregroundStyle(Color.red) }
                ForEach(coins) { c in
                    NavigationLink(value: c.symbol) { row(c) }
                }
            }
            .navigationTitle("Market")
            .searchable(text: $q)
            .navigationDestination(for: String.self) { CoinView(sym: $0) }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Picker("Sort", selection: $sort) {
                        Text("Market cap").tag("marketCap"); Text("24h %").tag("change24h")
                        Text("Volume").tag("volume24h"); Text("Newest").tag("createdAt")
                    }.pickerStyle(.menu)
                }
            }
            .task(id: "\(q)|\(sort)|\(key)") {
                do { try await Task.sleep(nanoseconds: 500_000_000) } catch { return }
                await load()
            }
            .refreshable { await load() }
        }
    }

    func row(_ c: MCoin) -> some View {
        let ch = c.change24h ?? 0
        return HStack {
            VStack(alignment: .leading) {
                Text("*\(c.symbol)").bold()
                Text("\(c.name ?? "") · cap \(fmt(c.marketCap ?? 0))").font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            VStack(alignment: .trailing) {
                Text("$" + fmt(c.currentPrice ?? 0))
                Text(String(format: "%.2f%%", ch)).font(.caption).foregroundStyle(ch >= 0 ? Color.green : Color.red)
            }
        }
    }

    func load() async {
        guard !key.isEmpty else { err = "Add your API key in the Key tab."; return }
        var comps = URLComponents()
        comps.queryItems = [URLQueryItem(name: "search", value: q), URLQueryItem(name: "sortBy", value: sort),
                            URLQueryItem(name: "sortOrder", value: "desc"), URLQueryItem(name: "limit", value: "50")]
        do {
            let r: MarketResp = try await Api.get("/market?" + (comps.percentEncodedQuery ?? ""), key: key)
            coins = r.coins; err = nil
        } catch { if !isCancel(error) { err = error.localizedDescription } }
    }
}

struct Pt: Identifiable { let id: Int; let k: Candle; let sma: Double?; let ema: Double? }

struct CoinView: View {
    let sym: String
    @AppStorage("apikey") private var key = ""
    @EnvironmentObject private var paper: Paper
    @State private var tf = "1h"
    @State private var resp: CoinResp?
    @State private var holders: [Holder] = []
    @State private var useSma = true
    @State private var useEma = false
    @State private var amt = "100"
    @State private var msg = ""
    @State private var err: String?

    var pts: [Pt] {
        let all = (resp?.candlestickData ?? []).sorted { $0.time < $1.time }
        let cl = all.map { $0.close }
        let s = smaOf(cl, 20), e = emaOf(cl, 20)
        let off = max(0, all.count - 120)
        return all.indices.filter { $0 >= off }.map { Pt(id: $0, k: all[$0], sma: s[$0], ema: e[$0]) }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                if let err { Text(err).foregroundStyle(Color.red) }
                if let c = resp?.coin {
                    Text("$" + fmt(c.currentPrice ?? 0)).font(.system(size: 34, weight: .bold, design: .rounded))
                    Text("\(c.name ?? "") · 24h " + String(format: "%.2f%%", c.change24h ?? 0)).foregroundStyle(.secondary)
                }
                Picker("Timeframe", selection: $tf) {
                    ForEach(["1m", "5m", "15m", "1h", "4h", "1d"], id: \.self) { Text($0).tag($0) }
                }.pickerStyle(.segmented)
                HStack {
                    Toggle("SMA 20", isOn: $useSma).toggleStyle(.button)
                    Toggle("EMA 20", isOn: $useEma).toggleStyle(.button)
                }
                chart
                if let c = resp?.coin { paperCard(c); stats(c) }
                if !holders.isEmpty {
                    Text("Top holders").font(.headline)
                    Text("A big creator share means rug risk").font(.caption).foregroundStyle(.secondary)
                    ForEach(holders) { h in
                        HStack { Text("#\(h.rank) @\(h.username ?? "?")"); Spacer(); Text(String(format: "%.2f%%", h.percentage ?? 0)) }
                    }
                }
            }.padding()
        }
        .navigationTitle("*\(sym)").navigationBarTitleDisplayMode(.inline)
        .task(id: tf) { await load() }
        .task { await loadHolders() }
    }

    @ViewBuilder var chart: some View {
        let p = pts
        if p.count < 2 {
            Text("No chart data").foregroundStyle(.secondary)
        } else {
            let lo = p.map { $0.k.low }.min() ?? 0, hi = p.map { $0.k.high }.max() ?? 1
            let pad = max((hi - lo) * 0.05, 1e-9)
            Chart {
                ForEach(p) { x in
                    RuleMark(x: .value("t", x.id), yStart: .value("L", x.k.low), yEnd: .value("H", x.k.high))
                        .foregroundStyle(x.k.close >= x.k.open ? Color.green : Color.red)
                    BarMark(x: .value("t", x.id), yStart: .value("O", min(x.k.open, x.k.close)),
                            yEnd: .value("C", max(x.k.open, x.k.close)), width: .fixed(4))
                        .foregroundStyle(x.k.close >= x.k.open ? Color.green : Color.red)
                }
                if useSma {
                    ForEach(p.filter { $0.sma != nil }) { x in
                        LineMark(x: .value("t", x.id), y: .value("SMA", x.sma ?? 0), series: .value("s", "SMA"))
                            .foregroundStyle(Color.yellow)
                    }
                }
                if useEma {
                    ForEach(p.filter { $0.ema != nil }) { x in
                        LineMark(x: .value("t", x.id), y: .value("EMA", x.ema ?? 0), series: .value("s", "EMA"))
                            .foregroundStyle(Color.blue)
                    }
                }
            }
            .chartYScale(domain: (lo - pad)...(hi + pad))
            .chartXAxis(.hidden)
            .frame(height: 260)
        }
    }

    func paperCard(_ c: CoinInfo) -> some View {
        let pc = c.poolCoinAmount ?? 0, pb = c.poolBaseCurrencyAmount ?? 0
        let held = paper.hold[sym] ?? 0
        return VStack(alignment: .leading, spacing: 8) {
            Text("Paper trading").font(.headline)
            Text("Fake money, local only. Cash $\(fmt(paper.cash)) · holding \(fmt(held)) \(sym)")
                .font(.caption).foregroundStyle(.secondary)
            TextField("Buy: $ to spend · Sell: coins", text: $amt).keyboardType(.decimalPad).textFieldStyle(.roundedBorder)
            HStack {
                Button("Buy") { msg = paper.buy(sym, Double(amt) ?? 0, pc, pb) }.buttonStyle(.borderedProminent).tint(.green)
                Button("Sell") { msg = paper.sell(sym, Double(amt) ?? 0, pc, pb) }.buttonStyle(.borderedProminent).tint(.red)
                Button("Reset") { paper.reset(); msg = "Reset to $1000" }.buttonStyle(.bordered)
            }
            if !msg.isEmpty { Text(msg).font(.caption) }
            if let u = URL(string: "https://rugplay.com/coin/\(sym)") { Link("Trade for real on rugplay.com ↗", destination: u) }
        }
        .padding().background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
    }

    func stats(_ c: CoinInfo) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Market cap $" + fmt(c.marketCap ?? 0))
            Text("24h volume $" + fmt(c.volume24h ?? 0))
            Text("Pool \(fmt(c.poolCoinAmount ?? 0)) coins / $\(fmt(c.poolBaseCurrencyAmount ?? 0))")
            Text("Creator \(c.creatorName ?? "") (@\(c.creatorUsername ?? ""))")
        }.font(.callout)
    }

    func load() async {
        do { let r: CoinResp = try await Api.get("/coin/\(sym)?timeframe=\(tf)", key: key); resp = r; err = nil }
        catch { if !isCancel(error) { err = error.localizedDescription } }
    }
    func loadHolders() async {
        if let r: HoldersResp = try? await Api.get("/holders/\(sym)?limit=10", key: key) { holders = r.holders }
    }
}

struct HopiumView: View {
    @AppStorage("apikey") private var key = ""
    @State private var qs: [Question] = []
    @State private var err: String?
    var body: some View {
        NavigationStack {
            List {
                if let err { Text(err).foregroundStyle(Color.red) }
                ForEach(qs) { q in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(q.question)
                        ProgressView(value: (q.yesPercentage ?? 0) / 100).tint(.green)
                        HStack {
                            Text(String(format: "YES %.1f%%", q.yesPercentage ?? 0)).foregroundStyle(Color.green)
                            Spacer(); Text("pool $" + fmt(q.totalAmount ?? 0)).foregroundStyle(.secondary)
                            Spacer(); Text(String(format: "NO %.1f%%", q.noPercentage ?? 0)).foregroundStyle(Color.red)
                        }.font(.caption)
                    }
                }
            }
            .navigationTitle("Hopium")
            .task(id: key) {
                guard !key.isEmpty else { err = "Add your API key in the Key tab."; return }
                do { let r: HopResp = try await Api.get("/hopium?status=ACTIVE&limit=50", key: key); qs = r.questions; err = nil }
                catch { if !isCancel(error) { err = error.localizedDescription } }
            }
        }
    }
}

struct TradeWeb: UIViewRepresentable {
    func makeUIView(context: Context) -> WKWebView {
        let w = WKWebView()
        if let u = URL(string: "https://rugplay.com/") { w.load(URLRequest(url: u)) }
        return w
    }
    func updateUIView(_ v: WKWebView, context: Context) {}
}

struct KeyView: View {
    @AppStorage("apikey") private var key = ""
    var body: some View {
        NavigationStack {
            Form {
                Section("Rugplay API key") {
                    TextField("rgpl_…", text: $key).textInputAutocapitalization(.never).autocorrectionDisabled()
                }
                Section {
                    Text("Stored only on this device. Limit: 2,000 requests/day. Buying, selling and rugging happen in the Trade tab, since the API is read-only.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }.navigationTitle("Key")
        }
    }
}
