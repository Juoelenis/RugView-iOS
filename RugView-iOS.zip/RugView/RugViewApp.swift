import SwiftUI

@main
struct RugViewApp: App {
    @StateObject private var paper = Paper()
    var body: some Scene {
        WindowGroup { RootView().environmentObject(paper).preferredColorScheme(.dark) }
    }
}

struct RootView: View {
    var body: some View {
        TabView {
            MarketView().tabItem { Label("Market", systemImage: "chart.line.uptrend.xyaxis") }
            HopiumView().tabItem { Label("Hopium", systemImage: "sparkles") }
            TradeWeb().ignoresSafeArea(edges: .bottom).tabItem { Label("Trade", systemImage: "cart") }
            KeyView().tabItem { Label("Key", systemImage: "key") }
        }
    }
}
